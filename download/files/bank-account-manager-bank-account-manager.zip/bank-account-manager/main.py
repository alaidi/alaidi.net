from tkinter import Tk
from ui.main_window import MainWindow

def main():
    root = Tk()
    root.title("Bank Account Manager")
    root.geometry("800x600")
    # root.resizable(False, False)
    MainWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()
