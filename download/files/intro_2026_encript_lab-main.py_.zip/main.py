def encript(text,shift):
    encrypted=""
    for i in text:
        n=ord(i)
        ch=chr(n+shift)
        encrypted+=ch
    return encrypted
def save_file(encrypted,filename):
    with open(filename,"w") as f:
        f.write(encrypted)
def load_file(filename):
    pass
text=input("Enter a string: ")
encrypted=encript(text,3)
save_file(encrypted,"encrypted.txt")
