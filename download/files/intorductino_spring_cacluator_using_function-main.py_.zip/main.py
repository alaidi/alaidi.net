def add(x,y):
    return x+y
def subtract(x,y):
    return x-y
def mult(x,y):
    return x*y
def divide(x,y):
    if y!=0:
        return x/y
    return "Error Can't divide by Zero"
def calculator(x,y,op):
    if op=='+':
        return add(x,y)
    if op=='-':
        return subtract(x,y)
    if op=='*':
        return mult(x,y)
    if op=='/':
        return divide(x,y)


while True:
    num1=int(input("first number> "))
    op=input("Operation (+,-,*,/)")
    num2=int(input("enter second number> "))
    r=calculator(num1,num2,op)
    print(r)